#!/bin/bash

source /opt/squid_set_vars.sh

parse_list(){
  URL=$1
  DIR=$SQUID_GUARD_DB/$2
  EXTR_SUBDIR=$3
  LIST="$DIR/temp.tar.gz"
  mkdir -p "$DIR" &&
  wget -O "$LIST" "$URL" && cd "$DIR" &&
  tar -xavf "$LIST" &&
  mv "$EXTR_SUBDIR"/* . &&
  rmdir "$EXTR_SUBDIR" 
  rm "$LIST" 2> /dev/null
}

parse_list 'http://squidguard.mesd.k12.or.us/blacklists.tgz' 'mesd' 'blacklists'
parse_list 'http://www.shallalist.de/Downloads/shallalist.tar.gz' 'shalla' 'BL'
chmod -R 755 "$SQUID_GUARD_DB" && chown -R squid:root "$SQUID_GUARD_DB" &&
squidGuard -b -C all

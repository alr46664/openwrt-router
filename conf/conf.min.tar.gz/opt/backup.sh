#!/bin/bash

source /opt/squid_set_vars.sh

TAR_FULLCONF_DEST="/opt/conf.tar.gz"
TAR_MINCONF_DEST="/opt/conf.min.tar.gz"

TAR_SYSTEM="$SYSCTL_CONF $LIMITS_CONF"
TAR_SQUID_GUARD="$SQUID_GUARD_LOG $SQUID_GUARD_CONF $BLACKLIST_UPDATE"
TAR_SQUID="$SQUID_LOG $SQUID/squid.conf $SQUID/conf.d/"

TAR_MINCONF="/opt/squid_set_vars.sh $BACKUP $TAR_SYSTEM $TAR_SQUID $TAR_SQUID_GUARD"
TAR_FULLCONF="$TAR_MINCONF $SQUID_GUARD_DB"

tar --acl --xattrs -czvpf "$TAR_FULLCONF_DEST" $TAR_FULLCONF
tar --acl --xattrs -czvpf "$TAR_MINCONF_DEST" $TAR_MINCONF

#!/bin/bash
export BACKUP=/opt/backup.sh

export SYSCTL_CONF=/etc/sysctl.conf
export LIMITS_CONF=/etc/security/limits.conf

export SQUID=/etc/squid
export SQUID_LOG=/var/log/squid/

export SQUID_GUARD_CONF=/etc/squidguard.conf
export SQUID_GUARD_DB=/var/lib/squidGuard/
export SQUID_GUARD_LOG=/var/log/squidGuard/

export BLACKLIST_UPDATE=/etc/cron.monthly/blacklist_update.sh
